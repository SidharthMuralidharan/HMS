import { Component, OnInit } from '@angular/core';
import { DummyService } from '../dummy.service';
import { Location } from '@angular/common';

@Component({
  selector: 'notFound',
  templateUrl: './pageNotfound.component.html'
})
export class NotFoundComponent implements OnInit {
  srcURL = 'https://pbs.twimg.com/media/DELMs5cWAAABEwh.jpg';
  constructor(private loc: Location) {
  }
  ngOnInit() { }
  backLogic() {
    this.loc.back();
  }
}
