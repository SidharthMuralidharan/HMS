import {Component, Inject} from '@angular/core';
import {MatDialog, MatDialogRef} from '@angular/material';


@Component({
  selector: 'dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})

export class DialogComponent {

  constructor(public dialog: MatDialog,public dialogRef: MatDialogRef<DialogComponent>) {}

  openDialog(): void {
    console.log('in');
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '250px'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed')
    });
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}