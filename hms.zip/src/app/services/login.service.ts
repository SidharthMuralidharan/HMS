import { Injectable } from '@angular/core';
import { Observable, of as obsOf } from 'rxjs';
import { USERS,user } from '../users';

@Injectable({
  providedIn: 'root',
})
export class LoginService {

  constructor() { }
  flag :Boolean = false;
  src:String="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOxrbQlyI37Ku8u3VB7z3GHJk1HZzLY1hJ90an_5asTZ9o9z1ZzA";
  loggeduser:user;
  getRegisteredUsers(): Observable<user[]> {
    return obsOf(USERS);
  }
  validateLoginDetails(detail:any):Observable<Boolean>{
    USERS.forEach(usr=>{
      if(usr.userId ==detail.userName && usr.password == detail.password){
       this.flag = true; 
      }
    })
    return obsOf(this.flag);
  }
  getUserImage(id:String):Observable<String>{
    USERS.forEach(i=>{
      if(i.userId ==id){
        this.src=i.imgSrc;
      }
    })
    return obsOf(this.src);
  }
  getUserDetail(name:string):Observable<user>{
    USERS.forEach(us=>{
      if(us.userId == name)
      this.loggeduser = us;
    })
    return obsOf(this.loggeduser);
  }
}