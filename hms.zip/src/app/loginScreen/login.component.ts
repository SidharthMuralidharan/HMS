import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { FormControl, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { LoginService } from '../services/login.service';
import { user } from '../users';
import { DialogComponent } from '../dialog/dialog.component';
import { MatDialog, MatDialogRef } from '@angular/material';

@Component({
  selector: 'login-screen',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  componentName: String = 'Login Screen';
  currentDateTime: any = '';
  isValid: Boolean = false;
  userEntry: user[];
  loginUserName: any;
  constructor(private router: Router, private datePipe: DatePipe, private logService: LoginService, public dialog: MatDialog) {
    this.currentDateTime = this.datePipe.transform(new Date(), 'dd/MM/yyyy hh:mm a');
  }
  ngOnInit(): void {
    // this.logService.getRegisteredUsers()
    // .subscribe(data => this.userEntry = data);
  }
  ngAfterViewInit() {
    //console.log(this.userEntry);
    console.log(DialogComponent.prototype.openDialog);
  }

  loginForm = new FormGroup({
    userName: new FormControl('', [
      Validators.required,
      Validators.minLength(4)
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(4)
    ])
  });
  go() {
    this.router.navigate(['/home', this.loginUserName], {});
  }
  validateLogin(): void {
    this.logService.validateLoginDetails(this.loginForm.value)
      .subscribe(data => this.isValid = data);
    if (this.isValid) {
      this.go();
    } else {
      alert('Invalid Combination\User Details Not Found.');
      //this.openErrorDialog();
    }
  }
  openErrorDialog(): void {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '250px'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
}