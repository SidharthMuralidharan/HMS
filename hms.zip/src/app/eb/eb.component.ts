import { Component ,OnInit} from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {DatePipe,Location} from '@angular/common';
import {MockData} from '../mock.dummy';
import { EbEntries } from '../mock.dummy';
import {DummyService} from '../dummy.service';

@Component({
  selector: 'eb-app',
  templateUrl: './eb.component.html',
  styleUrls: [ './eb.component.css' ]
})
export class EBComponent implements OnInit {
  name = 'Electricity';
  userName:any = '';
  ebentries:MockData[];
   currentDateTime :any;
  constructor(private router: Router, private activatedRoute: ActivatedRoute,public datepipe: DatePipe,
  public location:Location,private serv:DummyService) {
    this.currentDateTime = this.datepipe.transform(new Date(),'dd/MM/yyyy hh:mm a');
  }
    ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
        this.userName = params['user'];
      });
    this.getEbTableDatas();
  }
  backLogic(){
    this.location.back();
  }
  getEbTableDatas(){
    this.serv.getEbdatas()
      .subscribe(ebentry=> this.ebentries=ebentry)
  }
}