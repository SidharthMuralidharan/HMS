import { Component, OnInit, ElementRef, Renderer, Pipe, PipeTransform } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DatePipe, Location } from '@angular/common';
import { MockData } from '../mock.dummy';
import { DthEntries } from '../mock.dummy';
import { DummyService } from '../dummy.service';
import { LoginService } from '../services/login.service';
import { user } from '../users';

@Component({
  selector: 'dth-app',
  templateUrl: './dth.component.html',
  styleUrls: ['./dth.component.css']
})
@Pipe({
  name: "sort"
})
export class DTHComponent implements OnInit {
  name = 'DTH';
  userName: any = '';
  entries: MockData[];
  paginateEntries: MockData[];
  currentDateTime: any;
  iter: number = 0;
  loggedUserDetail:user;
  constructor(private router: Router, private activatedRoute: ActivatedRoute, public datepipe: DatePipe, public location: Location, private dservice: DummyService, public el: ElementRef, public renderer: Renderer,private logserv:LoginService) {
    this.currentDateTime = this.datepipe.transform(new Date(), 'dd/MM/yyyy hh:mm a');
  }
  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.userName = params['user'];
    });
    this.logserv.getUserDetail(this.userName)
    .subscribe(data =>this.loggedUserDetail = data);
    this.getDthTabledatas();
  }
  ngAfterViewInit() {
    this.dservice.getPaginationdatas()
      .subscribe(data => this.paginateEntries = data);
  }
  backLogic() {
    this.location.back();
  }
  getDthTabledatas(): void {
    this.dservice.getDthTabledatas()
      .subscribe(entry => this.entries = entry);
  }
  loadMore(): void {
    let i = 0;
    this.checkLoadMoreLabelStatus();
    if (!(this.iter > this.paginateEntries.length)) {
      for (i; i < 5; i++) {
        if (this.iter < this.paginateEntries.length) {
          this.entries.push(this.paginateEntries[this.iter]);
        }else{
          this.checkLoadMoreLabelStatus();
        }
        this.iter++;
      }
    }
  }
  checkLoadMoreLabelStatus(): void {
    if (this.iter >= this.paginateEntries.length) {
      let elem = document.querySelector('.load-more-main');
      if (elem) {
        let parent = elem.parentElement;
        parent.removeChild(elem);
      }
    }
    
  }
  onScroll(event: Event): void {
    // let element = event.target;
    // var x = element.scrollTop;
    // //let atBottom = element.scrollHeight - element.scrollTop === element.clientHeight
    // // var scrollTop = event.target.scrollTop;
    // // var scrollHeight = event.target.scrollHeight;
    // // var offsetHeight = event.target.offsetHeight;
    // // var scrollPosition = scrollTop + offsetHeight;
    // // var scrollTreshold = scrollHeight - this.pageHeight;
    // var totalHeight = element.scrollHeight;
    // if(element.scrollTop > (totalHeight/2)){
    //   //alert('halfwayReached');
    //   console.log('halfwayReached');
    // event.stopPropagation()
    // event.preventDefault();
    //}
  }
}