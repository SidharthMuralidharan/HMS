export class MockData {
  date: String;
  amount: Number;
  status: Boolean;
  type: String;
}
export const DthEntries: MockData[] = [
  { date: '01-02-2019', amount: 390, status: true, type: 'Card' },
  { date: '01-01-2019', amount: 390, status: true, type: 'Net Banking' },
  { date: '01-12-2018', amount: 390, status: true, type: 'Net Banking' },
  { date: '01-12-2018', amount: 390, status: true, type: 'Card' },
  { date: '03-10-2018', amount: 390, status: true, type: 'Card' }
]

export const EbEntries: MockData[] = [
  { date: '01-02-2019', amount: 4200, status: true, type: 'Card' },
  { date: '01-01-2019', amount: 3900, status: true, type: 'Net Banking' },
  { date: '01-12-2018', amount: 4125, status: true, type: 'Net Banking' },
  { date: '01-12-2018', amount: 4356, status: true, type: 'Card' },
  { date: '03-10-2018', amount: 2800, status: true, type: 'Card' }
]

export const paginationEntries: MockData[] = [
  { date: '01-02-2019', amount: 375, status: true, type: 'Card' },
  { date: '02-01-2019', amount: 390, status: true, type: 'Net Banking' },
  { date: '03-12-2018', amount: 415, status: true, type: 'Net Banking' },
  { date: '02-11-2018', amount: 375, status: true, type: 'Card' },
  { date: '01-10-2018', amount: 390, status: true, type: 'Card' },
  { date: '01-09-2018', amount: 415, status: true, type: 'Card' },
  { date: '02-08-2018', amount: 375, status: true, type: 'Net Banking' },
  { date: '03-07-2018', amount: 390, status: true, type: 'Net Banking' },
  { date: '02-06-2018', amount: 415, status: true, type: 'Card' },
  { date: '01-05-2018', amount: 375, status: true, type: 'Card' },
  { date: '02-04-2018', amount: 390, status: true, type: 'Net Banking' },
  { date: '03-03-2018', amount: 415, status: true, type: 'Net Banking' },
  { date: '02-02-2018', amount: 375, status: true, type: 'Card' },
  { date: '03-01-2018', amount: 390, status: true, type: 'Card' },
  { date: '01-12-2017', amount: 415, status: true, type: 'Net Banking' },
  { date: '03-11-2017', amount: 375, status: true, type: 'Net Banking' },
  { date: '02-10-2017', amount: 390, status: true, type: 'Card' },
  { date: '05-09-2017', amount: 415, status: true, type: 'Card' },
  { date: '03-08-2017', amount: 375, status: true, type: 'Net Banking' },
  { date: '06-07-2017', amount: 390, status: true, type: 'Net Banking' },
  { date: '02-06-2017', amount: 415, status: true, type: 'Card' },
  { date: '01-05-2017', amount: 375, status: true, type: 'Card' },
  { date: '03-04-2017', amount: 390, status: true, type: 'Net Banking' },
  { date: '02-03-2017', amount: 415, status: true, type: 'Net Banking' },
  { date: '01-02-2017', amount: 375, status: true, type: 'Card' },
  { date: '01-01-2017', amount: 390, status: true, type: 'Card' },
  { date: '02-12-2016', amount: 415, status: true, type: 'Net Banking' },
]