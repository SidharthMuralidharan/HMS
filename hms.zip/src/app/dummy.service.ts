import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import {MockData} from './mock.dummy';
import { DthEntries,EbEntries,paginationEntries } from './mock.dummy';

@Injectable({
  providedIn: 'root',
})
export class DummyService {

  constructor() { }
  getDthTabledatas(): Observable<MockData[]> {
    return of(DthEntries);
  }
  getEbdatas(): Observable<MockData[]> {
    return of(EbEntries);
  }
  getPaginationdatas(): Observable<MockData[]> {
    return of(paginationEntries);
  }
}