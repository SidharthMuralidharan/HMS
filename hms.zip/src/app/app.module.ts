import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { RouterModule,Routes } from '@angular/router';
import { MatExpansionModule } from '@angular/material/expansion';
import { ChartsModule } from 'ng2-charts';
import { NotFoundComponent } from './pageNotFound/pageNotfound.component';
import { AppComponent } from './app.component';
import { LoginComponent } from './loginScreen/login.component';
import { MainComponent } from './mainScreen/main.component';
import { InternetComponent } from './internet/internet.component';
import { DTHComponent } from './dth/dth.component';
import { PieChartComponent } from './pie/pie.component';
import { sortTable } from './dth/sort.pipe';
import { EBComponent } from './eb/eb.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDialogModule } from '@angular/material';
import { DialogComponent } from './dialog/dialog.component';

const applicationRoutes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'home/:user', component: MainComponent },
  { path: 'login', component: LoginComponent },
  { path: 'internet/:user', component: InternetComponent },
  { path: 'dth/:user', component: DTHComponent },
  { path: 'eb/:user', component: EBComponent },
  { path:'**', component:NotFoundComponent}
];

@NgModule({
  imports:[ RouterModule.forRoot(applicationRoutes, { enableTracing: true }),
  BrowserModule,BrowserAnimationsModule, FormsModule,ReactiveFormsModule,MatExpansionModule,
  ChartsModule,MatTabsModule,MatDialogModule  ],
  declarations: [ AppComponent,LoginComponent,MainComponent,InternetComponent,
  PieChartComponent,DTHComponent,sortTable,EBComponent,NotFoundComponent,DialogComponent ],
  bootstrap:    [ AppComponent ],
  providers:    [ DatePipe ],
  entryComponents : [ DialogComponent ]
})
export class AppModule { }
