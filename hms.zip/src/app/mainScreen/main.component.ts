import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { FormControl, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { LoginService } from '../services/login.service';
import { user } from '../users';

@Component({
  selector: 'main-screen',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})

export class MainComponent implements OnInit {
  componentName: String = 'Main Screen';
  currentDateTime: any = '';
  isValid: Boolean = false;
  userEntry:user[];
  userName:any;
  userImage:any;
  loggedUserDetail:user;
  xpandStatus=true;
  xpandStatus2=true;
  xpandStatus3=false;
  constructor(private datePipe: DatePipe,private logService: LoginService,private activatedRoute: ActivatedRoute) {
    this.currentDateTime = this.datePipe.transform(new Date(), 'dd/MM/yyyy hh:mm a');
  }
  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.userName = params['user'];
    });
    this.logService.getUserImage(this.userName)
    .subscribe(i => this.userImage = i);
    this.logService.getUserDetail(this.userName)
    .subscribe(usr=>this.loggedUserDetail= usr);
    console.log(this.loggedUserDetail)
  }
  ngAfterViewInit(){}
}