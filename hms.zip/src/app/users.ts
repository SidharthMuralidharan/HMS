export class user {
  userId: string;
  userName: String;
  password: any;
  imgSrc:string;
  phoneNumber:number;
  email:any;
  address:any;
}

export const USERS: user[] = [
  { userId: 'siddy', userName: 'Sidharth',password:"qwer@1234",
  imgSrc:"https://pbs.twimg.com/profile_images/1042073485600845824/F2GZnC77_400x400.jpg",
  phoneNumber:9856321470,email:"mranonymous_siddy@yahoo.com",address:"No 9, II Main,III Block, III Stage,Chennai - 97"},
  { userId: 'user1', userName: 'Dummy User One',password:"dummy@1234",
  imgSrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBjpkvX92AbKFC3uWSwBKjGPxTJMR8fkX4ZMyLjy-UbtmUZksa",phoneNumber:8547129036,email:"dummyuserone@yahoo.com",address:"No 9, II Main,III Block, III Stage,Chennai - 97"},
  { userId: 'user2', userName: 'Dummy User Two',password:"dummy@1234",
  imgSrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlUiASNL1BDUNvzSNkEU68YONnCHasRxVADzldOFCHc7BpHuDK",
  phoneNumber:8903214567,email:"dummyusertwo@yahoo.com",address:"No 9, II Main,III Block, III Stage,Chennai - 97"},
  { userId: 'user3', userName: 'Dummy User Tnree',password:"dummy@1234",imgSrc:"https://pbs.twimg.com/profile_images/1042073485600845824/F2GZnC77_400x400.jpg",
  phoneNumber:9512036547,email:"dummyuserthree@yahoo.com",address:"No 9, II Main,III Block, III Stage,Chennai - 97"},
  { userId: 'user4', userName: 'Dummy User Four',password:"dummy@1234",imgSrc:"https://pbs.twimg.com/profile_images/1042073485600845824/F2GZnC77_400x400.jpg",
  phoneNumber:8520369741,email:"dummyuserfour@yahoo.com",address:"No 9, II Main,III Block, III Stage,Chennai - 97"},
  { userId: 'user5', userName: 'Dummy User Five',password:"dummy@1234",imgSrc:"https://pbs.twimg.com/profile_images/1042073485600845824/F2GZnC77_400x400.jpg",
  phoneNumber:9785460132,email:"dummyuserfive@yahoo.com",address:"No 9, II Main,III Block, III Stage,Chennai - 97"}
];