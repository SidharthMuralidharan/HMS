import { Component ,OnInit} from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {DatePipe,Location} from '@angular/common';
import { LoginService } from '../services/login.service';
import { user } from '../users';

@Component({
  selector: 'internet-app',
  templateUrl: './internet.component.html',
  styleUrls: [ './internet.component.css' ]
})
export class InternetComponent implements OnInit {
  name = 'Internet';
  userName:any = '';
  currentDateTime :any;
  loggedUserDetail:user;
  constructor(private router: Router, private activatedRoute: ActivatedRoute,public datepipe: DatePipe,public loc:Location,private logserv:LoginService) {
    this.currentDateTime = this.datepipe.transform(new Date(),'dd/MM/yyyy hh:mm a');
  }
    ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
        this.userName = params['user'];
      });
    this.logserv.getUserDetail(this.userName)
    .subscribe(data =>this.loggedUserDetail = data);
  }
  backLogic(){
    this.loc.back();
  }

}