import { Component } from '@angular/core';
 
@Component({
  selector: 'pie-chart',
  templateUrl: './pie.component.html'
})
export class PieChartComponent {
  // Pie
  public pieChartLabels:string[] = ['Used Data', 'Remaining'];
  public pieChartData:number[] = [704, 320];
  public pieChartType:string = 'pie';
 
  // events
  public chartClicked(e:any):void {
    console.log(e);
  }
 
  public chartHovered(e:any):void {
    console.log(e);
  }
}